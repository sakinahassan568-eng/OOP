import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReportGeneration extends JFrame {
    private JTextField studentNameField;
    private JTextField fatherNameField; // Changed from rollNoField
    private JTextArea reportArea;

    public ReportGeneration() {
        setTitle("Report Generation");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(Color.LIGHT_GRAY);
        add(panel);
        placeComponents(panel);

        setVisible(true);
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel welcomeLabel = new JLabel("Report Generation", SwingConstants.CENTER);
        welcomeLabel.setBounds(250, 50, 300, 25);
        welcomeLabel.setForeground(Color.BLACK);
        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        panel.add(welcomeLabel);

        JLabel nameLabel = new JLabel("Student Name:");
        nameLabel.setBounds(200, 150, 100, 25);
        panel.add(nameLabel);

        studentNameField = new JTextField(20);
        studentNameField.setBounds(350, 150, 200, 25);
        panel.add(studentNameField);

        JLabel fatherNameLabel = new JLabel("Father's Name:"); // Changed label
        fatherNameLabel.setBounds(200, 200, 100, 25); // Adjusted position
        panel.add(fatherNameLabel);

        fatherNameField = new JTextField(20); // Changed field name
        fatherNameField.setBounds(350, 200, 200, 25); // Adjusted position
        panel.add(fatherNameField);

        JButton generateReportButton = new JButton("Generate Report");
        generateReportButton.setBounds(250, 250, 300, 25);
        generateReportButton.setForeground(Color.BLACK);
        generateReportButton.setBackground(Color.LIGHT_GRAY);
        panel.add(generateReportButton);

        generateReportButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                generateReport();
            }
        });

        reportArea = new JTextArea();
        reportArea.setBounds(150, 300, 500, 200);
        panel.add(reportArea);

        JButton backButton = new JButton("Back");
        backButton.setBounds(250, 520, 300, 25);
        backButton.setForeground(Color.BLACK);
        backButton.setBackground(Color.LIGHT_GRAY);
        panel.add(backButton);

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new TeacherDashboard(); // Assuming TeacherDashboard is another JFrame class
            }
        });
    }

    private void generateReport() {
        String studentName = studentNameField.getText();
        String fatherName = fatherNameField.getText().trim(); // Changed to fatherName

        if (fatherName.isEmpty()) { // Changed to fatherName
            JOptionPane.showMessageDialog(this, "Father's Name cannot be empty."); // Changed message
            return;
        }

        int studentID = getStudentIDByFatherName(fatherName); // Changed method call

        if (studentID != -1) {
            try (Connection connection = DatabaseConnection.getConnection()) {
                String query = "SELECT * FROM Attendance WHERE StudentID = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                preparedStatement.setInt(1, studentID);
                ResultSet resultSet = preparedStatement.executeQuery();

                StringBuilder reportContent = new StringBuilder();
                reportContent.append("Attendance Report for ").append(studentName).append(" (Father's Name: ").append(fatherName).append(")\n\n");

                while (resultSet.next()) {
                    String date = resultSet.getString("Date");
                    reportContent.append("Date: ").append(date).append("\n");
                }

                reportArea.setText(reportContent.toString());

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error retrieving data from database: " + ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Student with Father's Name " + fatherName + " not found."); // Changed message
        }
    }

    private int getStudentIDByFatherName(String fatherName) { // Changed method name
        int studentID = -1;
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT StudentID FROM Students WHERE FatherName = ?"; // Changed query
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, fatherName);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                studentID = resultSet.getInt("StudentID");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return studentID;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ReportGeneration();
            }
        });
    }
}
