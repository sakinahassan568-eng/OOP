import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AttendanceManagement extends JFrame {
    private JComboBox<String> studentComboBox;
    private JComboBox<String> statusComboBox;

    public AttendanceManagement() {
        setTitle("Attendance Management");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(Color.LIGHT_GRAY);
        add(panel);
        placeComponents(panel);

        setVisible(true);
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel welcomeLabel = new JLabel("Attendance Management", SwingConstants.CENTER);
        welcomeLabel.setBounds(250, 50, 300, 25);
        welcomeLabel.setForeground(Color.BLACK);
        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        panel.add(welcomeLabel);

        JLabel studentLabel = new JLabel("Select Student:");
        studentLabel.setBounds(200, 150, 100, 25);
        panel.add(studentLabel);

        String[] students = {"Ali (Father: Ibrahim)", "Sara (Father: Ali)", "Zara (Father: Yasir)", "Sana (Father: Ali)"};
        studentComboBox = new JComboBox<>(students);
        studentComboBox.setBounds(350, 150, 300, 25);
        panel.add(studentComboBox);

        JLabel statusLabel = new JLabel("Status:");
        statusLabel.setBounds(200, 200, 100, 25);
        panel.add(statusLabel);

        String[] statuses = {"Present", "Absent"};
        statusComboBox = new JComboBox<>(statuses);
        statusComboBox.setBounds(350, 200, 300, 25);
        panel.add(statusComboBox);

        JButton markAttendanceButton = new JButton("Mark Attendance");
        markAttendanceButton.setBounds(250, 250, 300, 25);
        markAttendanceButton.setForeground(Color.BLACK);
        markAttendanceButton.setBackground(Color.LIGHT_GRAY);
        panel.add(markAttendanceButton);

        markAttendanceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                markAttendance();
            }
        });

        JButton backButton = new JButton("Back");
        backButton.setBounds(250, 300, 300, 25);
        backButton.setForeground(Color.BLACK);
        backButton.setBackground(Color.LIGHT_GRAY);
        panel.add(backButton);

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new StudentDashboard(); // Navigate back to student dashboard
            }
        });
    }

    private void markAttendance() {
        String selectedStudent = (String) studentComboBox.getSelectedItem();

        // Parse selected student and father name from the combo box selection
        String studentName = selectedStudent.split(" \\(Father: ")[0];
        String fatherName = selectedStudent.split(" \\(Father: ")[1].replace(")", "");

        int studentID = getStudentIDByNameAndFatherName(studentName, fatherName);

        if (studentID != -1) {
            String status = (String) statusComboBox.getSelectedItem();

            try (Connection connection = DatabaseConnection.getConnection()) {
                String query = "INSERT INTO Attendance (StudentID, AttendanceDate, Status) VALUES (?, CURRENT_DATE, ?)";
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                preparedStatement.setInt(1, studentID);
                preparedStatement.setString(2, status);
                preparedStatement.executeUpdate();

                JOptionPane.showMessageDialog(this, "Attendance marked successfully!");
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error marking attendance: " + ex.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(this, "Student not found."); // Ideally, this should not occur if GUI and data are consistent
        }
    }

    private int getStudentIDByNameAndFatherName(String studentName, String fatherName) {
        int studentID = -1;

        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT s.StudentID FROM Students s JOIN Users u ON s.UserID = u.UserID WHERE s.Name = ? AND s.FatherName = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, studentName);
            preparedStatement.setString(2, fatherName);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                studentID = resultSet.getInt("StudentID");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return studentID;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new AttendanceManagement();
            }
        });
    }
}
