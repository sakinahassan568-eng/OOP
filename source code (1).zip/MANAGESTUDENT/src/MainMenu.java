import javax.swing.*;
import java.awt.*;

public class MainMenu extends JFrame {
    public MainMenu() {
        setTitle("Main Menu");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(Color.LIGHT_GRAY);
        add(panel);
        placeComponents(panel);

        setVisible(true);
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel welcomeLabel = new JLabel("Welcome to the Attendance Management System", SwingConstants.CENTER);
        welcomeLabel.setBounds(150, 100, 500, 25);
        welcomeLabel.setForeground(Color.BLACK);
        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        panel.add(welcomeLabel);

        JButton teacherButton = new JButton("Teacher Dashboard");
        teacherButton.setBounds(250, 200, 300, 25);
        teacherButton.setForeground(Color.BLACK);
        teacherButton.setBackground(Color.LIGHT_GRAY);
        panel.add(teacherButton);

        JButton studentButton = new JButton("Student Dashboard");
        studentButton.setBounds(250, 250, 300, 25);
        studentButton.setForeground(Color.BLACK);
        studentButton.setBackground(Color.LIGHT_GRAY);
        panel.add(studentButton);

        teacherButton.addActionListener(e -> {
            dispose();
            new TeacherDashboard();
        });

        studentButton.addActionListener(e -> {
            dispose();
            new StudentDashboard();
        });
    }
}
