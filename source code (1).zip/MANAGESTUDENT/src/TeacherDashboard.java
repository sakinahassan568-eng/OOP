import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TeacherDashboard {
    public TeacherDashboard() {
        JFrame frame = new JFrame("Teacher Dashboard");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(Color.LIGHT_GRAY);
        frame.add(panel);
        placeComponents(panel, frame);

        frame.setVisible(true);
    }

    private void placeComponents(JPanel panel, JFrame frame) {
        panel.setLayout(null);

        JLabel welcomeLabel = new JLabel("Teacher Dashboard", SwingConstants.CENTER);
        welcomeLabel.setBounds(250, 50, 300, 25);
        welcomeLabel.setForeground(Color.BLACK);
        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        panel.add(welcomeLabel);

        JButton manageAttendanceButton = new JButton("Manage Attendance");
        manageAttendanceButton.setBounds(250, 150, 300, 25);
        manageAttendanceButton.setForeground(Color.BLACK);
        manageAttendanceButton.setBackground(Color.LIGHT_GRAY);
        panel.add(manageAttendanceButton);

        JButton generateReportsButton = new JButton("Generate Reports");
        generateReportsButton.setBounds(250, 200, 300, 25);
        generateReportsButton.setForeground(Color.BLACK);
        generateReportsButton.setBackground(Color.LIGHT_GRAY);
        panel.add(generateReportsButton);

        manageAttendanceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new AttendanceManagement();
            }
        });

        generateReportsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new ReportGeneration();
            }
        });

        JButton backButton = new JButton("Back");
        backButton.setBounds(250, 250, 300, 25);
        backButton.setForeground(Color.BLACK);
        backButton.setBackground(Color.LIGHT_GRAY);
        panel.add(backButton);

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new MainMenu();
            }
        });
    }
}
