import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Signup extends JFrame {
    public Signup() {
        setTitle("Student Management System - Signup");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(Color.LIGHT_GRAY);
        add(panel);
        placeComponents(panel);

        setVisible(true);
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel welcomeLabel = new JLabel("Signup for Student Management System");
        welcomeLabel.setBounds(200, 50, 400, 50);
        welcomeLabel.setForeground(Color.BLACK);
        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        panel.add(welcomeLabel);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(150, 150, 200, 25);
        userLabel.setForeground(Color.BLACK);
        userLabel.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        panel.add(userLabel);

        JTextField userText = new JTextField(20);
        userText.setBounds(350, 150, 200, 25);
        userText.setForeground(Color.BLACK);
        userText.setBackground(Color.LIGHT_GRAY);
        panel.add(userText);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(150, 200, 200, 25);
        passwordLabel.setForeground(Color.BLACK);
        passwordLabel.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        panel.add(passwordLabel);

        JPasswordField passwordText = new JPasswordField(20);
        passwordText.setBounds(350, 200, 200, 25);
        passwordText.setForeground(Color.BLACK);
        passwordText.setBackground(Color.LIGHT_GRAY);
        panel.add(passwordText);

        JLabel userTypeLabel = new JLabel("User Type:");
        userTypeLabel.setBounds(150, 250, 200, 25);
        userTypeLabel.setForeground(Color.BLACK);
        userTypeLabel.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        panel.add(userTypeLabel);

        String[] userTypes = {"Teacher", "Student"};
        JComboBox<String> userTypeComboBox = new JComboBox<>(userTypes);
        userTypeComboBox.setBounds(350, 250, 200, 25);
        userTypeComboBox.setForeground(Color.BLACK);
        userTypeComboBox.setBackground(Color.LIGHT_GRAY);
        panel.add(userTypeComboBox);

        JButton signupButton = new JButton("Sign Up");
        signupButton.setBounds(300, 350, 100, 25);
        signupButton.setForeground(Color.BLACK);
        signupButton.setBackground(Color.LIGHT_GRAY);
        panel.add(signupButton);

        signupButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText();
                String password = new String(passwordText.getPassword());
                String userType = (String) userTypeComboBox.getSelectedItem();
                if (registerUser(username, password, userType)) {
                    JOptionPane.showMessageDialog(null, "Signup successful!");
                    dispose();
                    new Login();
                } else {
                    JOptionPane.showMessageDialog(null, "Signup failed!");
                }
            }
        });
    }

    private boolean registerUser(String username, String password, String userType) {
        try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "Student", "oracle")) {
            String query = "INSERT INTO Users (Username, Password, UserType) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, username);
                stmt.setString(2, password);
                stmt.setString(3, userType);
                stmt.executeUpdate();
                return true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Signup::new);
    }
}
