import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Login extends JFrame {
    public Login() {
        setTitle("Student Management System - Login");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(Color.LIGHT_GRAY);
        add(panel);
        placeComponents(panel);

        setVisible(true);
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel welcomeLabel = new JLabel("Welcome to Student Management System");
        welcomeLabel.setBounds(200, 50, 400, 50);
        welcomeLabel.setForeground(Color.BLACK);
        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        panel.add(welcomeLabel);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(150, 150, 200, 25);
        userLabel.setForeground(Color.BLACK);
        userLabel.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        panel.add(userLabel);

        JTextField userText = new JTextField(20);
        userText.setBounds(350, 150, 200, 25);
        userText.setForeground(Color.BLACK);
        userText.setBackground(Color.LIGHT_GRAY);
        panel.add(userText);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(150, 200, 200, 25);
        passwordLabel.setForeground(Color.BLACK);
        passwordLabel.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        panel.add(passwordLabel);

        JPasswordField passwordText = new JPasswordField(20);
        passwordText.setBounds(350, 200, 200, 25);
        passwordText.setForeground(Color.BLACK);
        passwordText.setBackground(Color.LIGHT_GRAY);
        panel.add(passwordText);

        JButton loginButton = new JButton("Sign in");
        loginButton.setBounds(250, 300, 100, 25);
        loginButton.setForeground(Color.BLACK);
        loginButton.setBackground(Color.LIGHT_GRAY);
        panel.add(loginButton);

        JButton signupButton = new JButton("Sign Up");
        signupButton.setBounds(400, 300, 100, 25);
        signupButton.setForeground(Color.BLACK);
        signupButton.setBackground(Color.LIGHT_GRAY);
        panel.add(signupButton);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText();
                String password = new String(passwordText.getPassword());
                if (authenticate(username, password)) {
                    dispose();
                    new MainMenu();
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password");
                }
            }
        });

        signupButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Signup();
            }
        });
    }

    private boolean authenticate(String username, String password) {
        try (Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "Student", "oracle")) {
            String query = "SELECT * FROM Users WHERE Username = ? AND Password = ?";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, username);
                stmt.setString(2, password);
                ResultSet rs = stmt.executeQuery();
                return rs.next();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Login::new);
    }
}
