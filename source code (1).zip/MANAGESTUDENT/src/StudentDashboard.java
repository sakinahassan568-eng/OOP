import javax.swing.*;
import java.awt.*;

public class StudentDashboard extends JFrame {
    private JComboBox<String> studentComboBox;

    public StudentDashboard() {
        setTitle("Student Dashboard");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setBackground(Color.LIGHT_GRAY);
        add(panel);
        placeComponents(panel);

        setVisible(true);
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel welcomeLabel = new JLabel("Student Dashboard", SwingConstants.CENTER);
        welcomeLabel.setBounds(250, 50, 300, 25);
        welcomeLabel.setForeground(Color.BLACK);
        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
        panel.add(welcomeLabel);

        JLabel selectStudentLabel = new JLabel("Select Student:");
        selectStudentLabel.setBounds(200, 150, 100, 25);
        panel.add(selectStudentLabel);

        studentComboBox = new JComboBox<>();
        studentComboBox.setBounds(350, 150, 200, 25);
        panel.add(studentComboBox);

        // Add student names to the combo box
        studentComboBox.addItem("Sara (Father: Ali)");
        studentComboBox.addItem("Sana (Father: Ali)");
        studentComboBox.addItem("Zara (Father: Yasir)");
        studentComboBox.addItem("Yarsha (Father: Yaseen)");
        studentComboBox.addItem("Anaum (Father: Ahmed)");

        JButton viewAttendanceButton = new JButton("View Attendance");
        viewAttendanceButton.setBounds(250, 200, 300, 25);
        viewAttendanceButton.setForeground(Color.BLACK);
        viewAttendanceButton.setBackground(Color.LIGHT_GRAY);
        panel.add(viewAttendanceButton);

        viewAttendanceButton.addActionListener(e -> {
            String selectedStudent = (String) studentComboBox.getSelectedItem();
            if (selectedStudent != null) {
                String studentName = selectedStudent.split(" \\(Father: ")[0];
                String fatherName = selectedStudent.split(" \\(Father: ")[1].replace(")", "");
                JOptionPane.showMessageDialog(this, "Selected Student: " + studentName + "\nFather's Name: " + fatherName);
            } else {
                JOptionPane.showMessageDialog(this, "Please select a student.");
            }
        });

        JButton backButton = new JButton("Back");
        backButton.setBounds(250, 250, 300, 25);
        backButton.setForeground(Color.BLACK);
        backButton.setBackground(Color.LIGHT_GRAY);
        panel.add(backButton);

        backButton.addActionListener(e -> {
            dispose();
            new MainMenu();
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new StudentDashboard();
        });
    }
}
